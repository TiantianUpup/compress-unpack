package com.h2t.study.service;

import com.h2t.study.po.Users;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hetiantian
 * @since 2019-08-13
 */
public interface UsersService extends BaseService<Users> {

}
